package lazycontroller

import "testing"

func TestBaseController(t *testing.T) {
	t.Fatal("This test needs to be implemented!")
}
