package lazycontroller

type Session Controller
